from datetime import date, datetime, time, timedelta, timezone
from io import BytesIO
import os, secrets, asyncio
import bcrypt, qrcode
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, WebSocket, WebSocketDisconnect, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text, create_engine, func, and_, or_, update
from sqlalchemy.orm import Session, declarative_base, sessionmaker, object_session

BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BACKEND_DIR, ".env"))
_default_db_path = os.path.join(BACKEND_DIR, "smartevent.db").replace("\\", "/")
DATABASE_URL = os.getenv("DATABASE_URL") or f"sqlite:///{_default_db_path}"

if DATABASE_URL.startswith("sqlite:///./"):
    _relative_db_path = DATABASE_URL[len("sqlite:///./"):]
    DATABASE_URL = "sqlite:///" + os.path.join(BACKEND_DIR, _relative_db_path).replace("\\", "/")
SECRET_KEY = os.getenv("SECRET_KEY") or secrets.token_urlsafe(48)
if not os.getenv("SECRET_KEY"):
    print("WARNING: SECRET_KEY is not set. A temporary random key is being used for this development run; configure backend/.env for stable sessions.")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True); username = Column(String(50), nullable=False); email = Column(String(120), unique=True, nullable=False)
    hashed_password = Column(String, nullable=False); created_at = Column(DateTime, default=datetime.utcnow); role = Column(String(20), nullable=False, default="USER")
class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True); title = Column(String(150), nullable=False); description = Column(Text, nullable=False)
    category = Column(String(30), nullable=False); location = Column(String(150), nullable=False); event_date = Column(DateTime, nullable=False)
    ticket_price = Column(Float, nullable=False); banner_image = Column(String, nullable=True); available_tickets = Column(Integer, default=100)
    created_at = Column(DateTime, default=datetime.utcnow); organizer_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    event_status = Column(String(20), nullable=False, default="UPCOMING")
class Booking(Base):
    __tablename__ = "bookings"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"), nullable=False); event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    ticket_quantity = Column(Integer, nullable=False); total_price = Column(Float, nullable=False); booking_status = Column(String(20), default="PENDING_PAYMENT"); created_at = Column(DateTime, default=datetime.utcnow)
    coupon_id = Column(Integer, ForeignKey("coupons.id"), nullable=True); discount_amount = Column(Float, default=0); final_amount = Column(Float, default=0)
class Ticket(Base):
    __tablename__ = "tickets"
    id = Column(Integer, primary_key=True); booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False); ticket_code = Column(String(50), unique=True, nullable=False)
    qr_code_url = Column(String, nullable=False); created_at = Column(DateTime, default=datetime.utcnow)
class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"), nullable=False); title = Column(String(150), nullable=False)
    message = Column(Text, nullable=False); type = Column("notification_type", String(20), nullable=False); is_read = Column(Integer, default=0); created_at = Column(DateTime, default=datetime.utcnow)

class Payment(Base):
    __tablename__ = "payments"
    id = Column(Integer, primary_key=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=False)
    payment_method = Column(String(30), nullable=False, default="SIMULATED")
    payment_status = Column(String(20), nullable=False, default="PENDING")
    transaction_id = Column(String(100), unique=True, nullable=True)
    amount = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Coupon(Base):
    __tablename__ = "coupons"
    id = Column(Integer, primary_key=True)
    coupon_code = Column(String(40), unique=True, nullable=False)
    discount_type = Column(String(20), nullable=False)
    discount_value = Column(Float, nullable=False)
    minimum_booking_amount = Column(Float, default=0)
    expiry_date = Column(DateTime, nullable=True)
    usage_limit = Column(Integer, default=100)
    usage_count = Column(Integer, default=0)
    is_active = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)

class Review(Base):
    __tablename__ = "reviews"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    rating = Column(Integer, nullable=False)
    review_text = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class Wishlist(Base):
    __tablename__ = "wishlist"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class EventUpdate(Base):
    __tablename__ = "event_updates"
    id = Column(Integer, primary_key=True)
    event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    message = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)

class EventView(Base):
    __tablename__ = "event_views"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    event_id = Column(Integer, ForeignKey("events.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class UserProfile(Base):
    __tablename__ = "user_profiles"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    profile_picture = Column(String(500), nullable=True)
    location = Column(String(150), nullable=True)

Base.metadata.create_all(bind=engine)
def migrate_legacy_db():
    if not DATABASE_URL.startswith("sqlite"): return
    with engine.begin() as conn:
        tables = {r[0] for r in conn.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        for table, fields in {
            "users": [("role", "VARCHAR(20) NOT NULL DEFAULT 'USER'")],
            "events": [("organizer_id", "INTEGER REFERENCES users(id)"), ("event_status", "VARCHAR(20) NOT NULL DEFAULT 'UPCOMING'")],
            "bookings": [("coupon_id", "INTEGER REFERENCES coupons(id)"), ("discount_amount", "FLOAT NOT NULL DEFAULT 0"), ("final_amount", "FLOAT NOT NULL DEFAULT 0")],
            "notifications": [("notification_type", "VARCHAR(20) NOT NULL DEFAULT 'SYSTEM'")]
        }.items():
            if table in tables:
                cols = {r[1] for r in conn.exec_driver_sql(f"PRAGMA table_info({table})").fetchall()}
                for name, declaration in fields:
                    if name not in cols:
                        conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {name} {declaration}")
                        cols.add(name)
                if table == "notifications" and "type" in cols and "notification_type" in cols:
                    conn.exec_driver_sql("UPDATE notifications SET notification_type = type WHERE notification_type = 'SYSTEM'")
       
        if "bookings" in tables:
            cols = {r[1] for r in conn.exec_driver_sql("PRAGMA table_info(bookings)").fetchall()}
            if {"final_amount", "total_price", "discount_amount", "coupon_id"}.issubset(cols):
                conn.exec_driver_sql("UPDATE bookings SET final_amount = total_price WHERE final_amount = 0 AND COALESCE(discount_amount, 0) = 0 AND coupon_id IS NULL AND total_price > 0")
migrate_legacy_db()



def add_sample_events():
    db = SessionLocal()
    try:
        events = [
            ("Hyderabad Tech Meetup", "Learn about Python, APIs, and modern web development.", "Tech", "HITEX, Hyderabad",
             datetime(2026, 10, 20, 10, 45), 999, 100),
            ("Live Music Night", "Enjoy live music and performances with friends.", "Music", "Gachibowli, Hyderabad",
             datetime(2026, 10, 27, 20, 30), 1499, 200),
            ("Business Conference", "Talks about startups, business, and leadership.", "Business", "HICC, Hyderabad",
             datetime(2026, 11, 3, 9, 30), 1999, 150),
            ("Sports Meet", "A day of sports activities and friendly competitions.", "Sports", "LB Stadium, Hyderabad",
             datetime(2026, 11, 10, 7, 30), 799, 300),
        ]

        for title, description, category, location, event_date, price, tickets in events:
            event = db.query(Event).filter(Event.title == title).first()
            if not event:
                db.add(Event(
                    title=title, description=description, category=category,
                    location=location, event_date=event_date, ticket_price=price,
                    banner_image=None, available_tickets=tickets,
                    organizer_id=None, event_status="UPCOMING"
                ))

        db.commit()
        print("Sample events checked; existing event dates and ticket settings were preserved.")
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
add_sample_events()
def bootstrap_admins():
    emails = [x.strip().lower() for x in os.getenv("ADMIN_EMAILS", "").split(",") if x.strip()]
    if not emails: return
    db = SessionLocal()
    try:
        db.query(User).filter(func.lower(User.email).in_(emails)).update({User.role: "ADMIN"}, synchronize_session=False)
        db.commit()
    finally: db.close()
bootstrap_admins()
def seed_coupons():
    db=SessionLocal()
    try:
        if not db.query(Coupon).filter(Coupon.coupon_code=="WELCOME10").first():
            db.add(Coupon(coupon_code="WELCOME10",discount_type="PERCENTAGE",discount_value=10,minimum_booking_amount=100,usage_limit=1000,usage_count=0,is_active=1))
        if not db.query(Coupon).filter(Coupon.coupon_code=="SAVE50").first():
            db.add(Coupon(coupon_code="SAVE50",discount_type="FIXED",discount_value=50,minimum_booking_amount=250,usage_limit=500,usage_count=0,is_active=1))
        db.commit()
    finally: db.close()
seed_coupons()
app = FastAPI(title="SmartEvent API", version="4.0.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","), allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
security = HTTPBearer(auto_error=False)
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
def sync_status(event):
    if event.event_status == "CANCELLED": return "CANCELLED"
    now = datetime.utcnow()
    return "UPCOMING" if now < event.event_date else "ONGOING" if now < event.event_date + timedelta(days=1) else "COMPLETED"
def normalize_event_date(value):
    return value.astimezone(timezone.utc).replace(tzinfo=None) if value.tzinfo else value
def token_for(user): return jwt.encode({"user_id": user.id, "role": user.role, "exp": datetime.utcnow()+timedelta(hours=2)}, SECRET_KEY, algorithm="HS256")
def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(security), db: Session = Depends(get_db)):
    if not credentials: raise HTTPException(401, "Authentication required", headers={"WWW-Authenticate":"Bearer"})
    try: payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=["HS256"]); uid, role = payload.get("user_id"), payload.get("role")
    except JWTError: raise HTTPException(401, "Invalid or expired token")
    user = db.query(User).filter(User.id == uid).first()
    if not user or user.role != role: raise HTTPException(401, "Invalid or expired token")
    return user
def require_roles(*roles):
    def guard(user: User = Depends(current_user)):
        if user.role not in roles: raise HTTPException(403, "Insufficient permissions")
        return user
    return guard
def event_dict(e):
    status = sync_status(e)
    if e.event_status != status:
        e.event_status = status
        db = object_session(e)
        if db: db.commit()
    return {"id":e.id,"title":e.title,"description":e.description,"category":e.category,"location":e.location,"event_date":e.event_date.isoformat(),"ticket_price":e.ticket_price,"banner_image":e.banner_image,"available_tickets":e.available_tickets,"organizer_id":e.organizer_id,"event_status":status}
def booking_dict(b,e): return {"id":b.id,"event_id":e.id,"event_title":e.title,"event_date":e.event_date.isoformat(),"event_status":sync_status(e),"location":e.location, "ticket_quantity":b.ticket_quantity,"total_price":b.total_price,"discount_amount":getattr(b,"discount_amount",0) or 0,"final_amount":b.final_amount if b.final_amount is not None else b.total_price,"booking_status":b.booking_status,"created_at":b.created_at.isoformat(),"user_id":b.user_id}
def notify_bookers(db,e,title,message):
    for (uid,) in db.query(Booking.user_id).filter(Booking.event_id==e.id,Booking.booking_status=="CONFIRMED").distinct().all(): db.add(Notification(user_id=uid,title=title,message=message,type="EVENT",is_read=0))
class RegisterData(BaseModel): username:str=Field(min_length=2,max_length=50); email:EmailStr; password:str=Field(min_length=6,max_length=100)
class LoginData(BaseModel): email:EmailStr; password:str
class BookingData(BaseModel): event_id:int; ticket_quantity:int=Field(ge=1,le=10); coupon_code:str|None=Field(default=None,max_length=40)
class CouponCheck(BaseModel): coupon_code:str=Field(min_length=2,max_length=40); amount:float=Field(ge=0)
class CouponData(BaseModel):
    coupon_code:str=Field(min_length=2,max_length=40); discount_type:str; discount_value:float=Field(gt=0); minimum_booking_amount:float=Field(ge=0,default=0)
    expiry_date:datetime|None=None; usage_limit:int=Field(ge=1,default=100); is_active:bool=True
class PaymentResult(BaseModel): result:str
class ApplyCoupon(BaseModel): coupon_code:str=Field(min_length=2,max_length=40)
class ReviewData(BaseModel): rating:int=Field(ge=1,le=5); review_text:str=Field(default="",max_length=2000)
class EventData(BaseModel):
    title:str=Field(min_length=3,max_length=150); description:str=Field(min_length=5,max_length=5000); category:str=Field(min_length=2,max_length=30)
    location:str=Field(min_length=2,max_length=150); event_date:datetime; ticket_price:float=Field(ge=0); available_tickets:int=Field(ge=1,le=1000000); banner_image:str|None=Field(default=None,max_length=1000)
class RoleUpdate(BaseModel): role:str

class ProfileUpdate(BaseModel):
    username: str = Field(min_length=2, max_length=50)
    location: str | None = Field(default=None, max_length=150)

class EventUpdateData(BaseModel):
    message: str = Field(min_length=2, max_length=2000)

class ChatData(BaseModel):
    message: str = Field(min_length=1, max_length=1000)

@app.get("/")
def home(): return {"message":"SmartEvent API is running","version":"4.0.0"}
@app.post("/auth/register")
def register(data:RegisterData,db:Session=Depends(get_db)):
    if db.query(User).filter(User.email==data.email).first(): raise HTTPException(400,"Email already registered")
    admins={x.strip().lower() for x in os.getenv("ADMIN_EMAILS","").split(",") if x.strip()}
    user=User(username=data.username,email=data.email,hashed_password=bcrypt.hashpw(data.password.encode(),bcrypt.gensalt()).decode(),role="ADMIN" if data.email.lower() in admins else "USER")
    db.add(user);db.commit();return {"message":"Registration successful"}
@app.post("/auth/login")
def login(data:LoginData,db:Session=Depends(get_db)):
    u=db.query(User).filter(User.email==data.email).first()
    if not u or not bcrypt.checkpw(data.password.encode(),u.hashed_password.encode()): raise HTTPException(401,"Invalid email or password")
    return {"access_token":token_for(u),"token_type":"bearer","user":{"id":u.id,"username":u.username,"email":u.email,"role":u.role}}
@app.get("/auth/profile")
def profile(user:User=Depends(current_user)): return {"id":user.id,"username":user.username,"email":user.email,"role":user.role,"created_at":user.created_at.isoformat()}
@app.get("/events")
def events(category:str|None=None,search:str|None=None,location:str|None=None,start_date:date|None=None,end_date:date|None=None,sort_by:str="date",min_price:float|None=None,max_price:float|None=None,db:Session=Depends(get_db)):
    q=db.query(Event).filter(Event.event_status!="CANCELLED")
    if category and category!="All": q=q.filter(Event.category==category)
    if search: q=q.filter((Event.title.ilike(f"%{search}%")) | (Event.description.ilike(f"%{search}%")))
    if location: q=q.filter(Event.location.ilike(f"%{location}%"))
    if min_price is not None: q=q.filter(Event.ticket_price >= min_price)
    if max_price is not None: q=q.filter(Event.ticket_price <= max_price)
    if start_date: q=q.filter(Event.event_date>=datetime.combine(start_date,time.min))
    if end_date: q=q.filter(Event.event_date<datetime.combine(end_date+timedelta(days=1),time.min))
    rows=q.all()
    if sort_by=="price": rows.sort(key=lambda e:e.ticket_price)
    elif sort_by=="popularity":
        counts=dict(db.query(Booking.event_id,func.coalesce(func.sum(Booking.ticket_quantity),0)).filter(Booking.booking_status=="CONFIRMED").group_by(Booking.event_id).all())
        rows.sort(key=lambda e:counts.get(e.id,0),reverse=True)
    else: rows.sort(key=lambda e:e.event_date)
    return [event_dict(e) for e in rows]
@app.get("/events/categories/list")
def categories(db:Session=Depends(get_db)):
    values = [row[0] for row in db.query(Event.category).filter(Event.event_status != "CANCELLED").distinct().order_by(Event.category).all()]
    return ["All", *values]
@app.get("/events/{event_id}")
def get_event(event_id:int,db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    return event_dict(e)
@app.post("/events")
def create_event(data:EventData,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    values=data.model_dump();values["event_date"]=normalize_event_date(values["event_date"])
    e=Event(**values,organizer_id=user.id,event_status="UPCOMING");db.add(e);db.commit();db.refresh(e);return event_dict(e)
@app.get("/organizer/events")
def my_events(user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    q=db.query(Event)
    if user.role!="ADMIN": q=q.filter(Event.organizer_id==user.id)
    return [event_dict(e) for e in q.order_by(Event.event_date.desc()).all()]
@app.put("/events/{event_id}")
def update_event(event_id:int,data:EventData,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    if user.role!="ADMIN" and e.organizer_id!=user.id: raise HTTPException(403,"You can only manage your own events")
    if e.event_status=="CANCELLED": raise HTTPException(400,"Cancelled events cannot be edited")
    values=data.model_dump();values["event_date"]=normalize_event_date(values["event_date"])
    for k,v in values.items(): setattr(e,k,v)
    e.event_status=sync_status(e);notify_bookers(db,e,"Event updated",f"{e.title} has been updated. Review the latest details.");db.commit();return event_dict(e)
@app.post("/events/{event_id}/cancel")
def cancel_event(event_id:int,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    if user.role!="ADMIN" and e.organizer_id!=user.id: raise HTTPException(403,"You can only manage your own events")
    if e.event_status!="CANCELLED": e.event_status="CANCELLED";notify_bookers(db,e,"Event cancelled",f"{e.title} has been cancelled. Contact support about refunds.");db.commit()
    return event_dict(e)
def booking_rows(user,db,event_id=None):
    q=db.query(Booking,Event,User).join(Event,Booking.event_id==Event.id).join(User,Booking.user_id==User.id)
    if user.role!="ADMIN":q=q.filter(Event.organizer_id==user.id)
    if event_id is not None:q=q.filter(Event.id==event_id)
    return [{**booking_dict(b,e),"username":u.username,"email":u.email} for b,e,u in q.order_by(Booking.created_at.desc()).all()]
@app.get("/organizer/bookings")
def organizer_bookings(user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):return booking_rows(user,db)
@app.get("/organizer/events/{event_id}/bookings")
def event_bookings(event_id:int,user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e:raise HTTPException(404,"Event not found")
    if user.role!="ADMIN" and e.organizer_id!=user.id:raise HTTPException(403,"You can only view bookings for your own events")
    return booking_rows(user,db,event_id)
@app.get("/organizer/analytics")
def organizer_analytics(user:User=Depends(require_roles("ORGANIZER","ADMIN")),db:Session=Depends(get_db)):
    q=db.query(Event)
    if user.role!="ADMIN":q=q.filter(Event.organizer_id==user.id)
    result=[]
    for e in q.all():
        sold,revenue,count=db.query(func.coalesce(func.sum(Booking.ticket_quantity),0),func.coalesce(func.sum(Booking.final_amount),0),func.count(Booking.id)).filter(Booking.event_id==e.id,Booking.booking_status=="CONFIRMED").one()
        result.append({"event_id":e.id,"event_title":e.title,"tickets_sold":int(sold),"remaining_tickets":e.available_tickets,"revenue":float(revenue),"booking_count":int(count)})
    return {"events":result,"totals":{"tickets_sold":sum(x["tickets_sold"] for x in result),"remaining_tickets":sum(x["remaining_tickets"] for x in result),"revenue":sum(x["revenue"] for x in result),"booking_count":sum(x["booking_count"] for x in result)}}
@app.get("/admin/users")
def admin_users(user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    return [{"id":u.id,"username":u.username,"email":u.email,"role":u.role,"created_at":u.created_at.isoformat()} for u in db.query(User).order_by(User.created_at.desc()).all()]
@app.patch("/admin/users/{user_id}/role")
def set_role(user_id:int,data:RoleUpdate,user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    role=data.role.upper()
    if role not in ("USER","ORGANIZER","ADMIN"):raise HTTPException(422,"Role must be USER, ORGANIZER, or ADMIN")
    target=db.query(User).filter(User.id==user_id).first()
    if not target:raise HTTPException(404,"User not found")
    target.role=role;db.commit();return {"id":target.id,"role":target.role}
@app.get("/admin/events")
def admin_events(user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):return [event_dict(e) for e in db.query(Event).order_by(Event.event_date.desc()).all()]
@app.get("/admin/bookings")
def admin_bookings(user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):return booking_rows(user,db)
@app.get("/admin/analytics")
def admin_analytics(start_date:date|None=None,end_date:date|None=None,user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    q=db.query(Booking,Event).join(Event,Booking.event_id==Event.id).filter(Booking.booking_status=="CONFIRMED")
    if start_date:q=q.filter(Booking.created_at>=datetime.combine(start_date,time.min))
    if end_date:q=q.filter(Booking.created_at<datetime.combine(end_date+timedelta(days=1),time.min))
    rows=q.all();daily={};monthly={};popular={};top={}
    for b,e in rows:
        d=b.created_at.date().isoformat();m=b.created_at.strftime("%Y-%m");daily[d]=daily.get(d,0)+b.ticket_quantity;monthly[m]=monthly.get(m,0)+1;popular[e.title]=popular.get(e.title,0)+b.ticket_quantity;top[e.title]=top.get(e.title,0)+(b.final_amount if b.final_amount is not None else b.total_price)
    return {"total_users":db.query(func.count(User.id)).scalar() or 0,"total_events":db.query(func.count(Event.id)).scalar() or 0,"total_bookings":len(rows),"total_tickets_sold":sum(b.ticket_quantity for b,e in rows),"total_revenue":sum((b.final_amount if b.final_amount is not None else b.total_price) for b,e in rows),"daily_ticket_sales":[{"date":k,"tickets":v} for k,v in sorted(daily.items())],"monthly_booking_trends":[{"month":k,"bookings":v} for k,v in sorted(monthly.items())],"popular_events":[{"event":k,"tickets":v} for k,v in sorted(popular.items(),key=lambda x:x[1],reverse=True)[:10]],"top_revenue_events":[{"event":k,"revenue":v} for k,v in sorted(top.items(),key=lambda x:x[1],reverse=True)[:10]]}
@app.post("/bookings")
def create_booking(data:BookingData,user:User=Depends(require_roles("USER")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==data.event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    e.event_status=sync_status(e)
    if e.event_status != "UPCOMING": raise HTTPException(400,"This event is not accepting bookings")
    if data.ticket_quantity>e.available_tickets: raise HTTPException(400,"Tickets are sold out or unavailable")
    subtotal=round(e.ticket_price*data.ticket_quantity,2); discount=0.0; coupon=None
    if data.coupon_code:
        coupon=db.query(Coupon).filter(func.upper(Coupon.coupon_code)==data.coupon_code.strip().upper()).first()
        if not coupon or not coupon.is_active: raise HTTPException(400,"Invalid or inactive coupon")
        if coupon.expiry_date and coupon.expiry_date < datetime.utcnow(): raise HTTPException(400,"Coupon has expired")
        if coupon.usage_count >= coupon.usage_limit: raise HTTPException(400,"Coupon usage limit reached")
        if subtotal < coupon.minimum_booking_amount: raise HTTPException(400,f"Minimum booking amount is ₹{coupon.minimum_booking_amount:.2f}")
        discount=subtotal*coupon.discount_value/100 if coupon.discount_type=="PERCENTAGE" else coupon.discount_value
        discount=round(min(subtotal,discount),2)
    final=round(max(0,subtotal-discount),2)
    b=Booking(user_id=user.id,event_id=e.id,ticket_quantity=data.ticket_quantity,total_price=subtotal,booking_status="PENDING_PAYMENT",coupon_id=coupon.id if coupon else None,discount_amount=discount,final_amount=final)
    db.add(b)
    db.flush()
    p=Payment(booking_id=b.id,payment_method="SIMULATED",payment_status="PENDING",amount=final)
    db.add(p)
    db.add(Notification(user_id=user.id,title="Payment pending",message=f"Complete payment for {e.title} to confirm your booking.",type="PAYMENT",is_read=0))
    db.commit()
    db.refresh(b)
    db.refresh(p)
    return {"message":"Booking created; payment required","booking":booking_dict(b,e),"payment":{"id":p.id,"payment_status":p.payment_status,"amount":p.amount,"payment_method":p.payment_method},"subtotal":subtotal,"discount_amount":discount,"final_amount":final}
@app.get("/bookings")
def my_bookings(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return [booking_dict(b,e) for b,e in db.query(Booking,Event).join(Event,Booking.event_id==Event.id).filter(Booking.user_id==user.id).order_by(Booking.created_at.desc()).all()]
@app.post("/bookings/{booking_id}/cancel")
def cancel_booking(booking_id:int,user:User=Depends(require_roles("USER","ADMIN")),db:Session=Depends(get_db)):
    query=db.query(Booking).filter(Booking.id==booking_id)
    if user.role!="ADMIN": query=query.filter(Booking.user_id==user.id)
    booking=query.first()
    if not booking: raise HTTPException(404,"Booking not found")
    if booking.booking_status!="CONFIRMED": raise HTTPException(400,"This booking is already cancelled")
    event=db.query(Event).filter(Event.id==booking.event_id).first()
    if not event: raise HTTPException(404,"Event not found")
    if event.event_date<=datetime.utcnow(): raise HTTPException(400,"Bookings can only be cancelled before the event starts")
    booking.booking_status="CANCELLED"
    event.available_tickets+=booking.ticket_quantity
    message=f"Your booking for {event.title} has been cancelled." if user.role!="ADMIN" else f"An administrator cancelled your booking for {event.title}."
    db.add(Notification(user_id=booking.user_id,title="Booking cancelled",message=message,type="BOOKING",is_read=0))
    db.commit()
    return {"message":"Booking cancelled","booking_id":booking.id,"available_tickets":event.available_tickets}

def payment_dict(p):
    return {"id":p.id,"booking_id":p.booking_id,"payment_method":p.payment_method,"payment_status":p.payment_status,"transaction_id":p.transaction_id,"amount":p.amount,"created_at":p.created_at.isoformat()}

@app.post("/coupons/validate")
def validate_coupon(data:CouponCheck,user:User=Depends(current_user),db:Session=Depends(get_db)):
    c=db.query(Coupon).filter(func.upper(Coupon.coupon_code)==data.coupon_code.strip().upper()).first()
    if not c or not c.is_active: raise HTTPException(400,"Invalid or inactive coupon")
    if c.expiry_date and c.expiry_date < datetime.utcnow(): raise HTTPException(400,"Coupon has expired")
    if c.usage_count >= c.usage_limit: raise HTTPException(400,"Coupon usage limit reached")
    if data.amount < c.minimum_booking_amount: raise HTTPException(400,f"Minimum booking amount is ₹{c.minimum_booking_amount:.2f}")
    discount=data.amount*c.discount_value/100 if c.discount_type=="PERCENTAGE" else c.discount_value
    discount=round(min(data.amount,discount),2)
    return {"valid":True,"coupon_code":c.coupon_code,"discount_type":c.discount_type,"discount_value":c.discount_value,"discount_amount":discount,"final_amount":round(data.amount-discount,2)}

@app.get("/admin/coupons")
def list_coupons(user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    return [{"id":c.id,"coupon_code":c.coupon_code,"discount_type":c.discount_type,"discount_value":c.discount_value,"minimum_booking_amount":c.minimum_booking_amount,"expiry_date":c.expiry_date.isoformat() if c.expiry_date else None,"usage_limit":c.usage_limit,"usage_count":c.usage_count,"is_active":bool(c.is_active)} for c in db.query(Coupon).order_by(Coupon.created_at.desc()).all()]

@app.post("/admin/coupons")
def create_coupon(data:CouponData,user:User=Depends(require_roles("ADMIN")),db:Session=Depends(get_db)):
    code=data.coupon_code.strip().upper()
    if data.discount_type.upper() not in ("PERCENTAGE","FIXED"): raise HTTPException(422,"discount_type must be PERCENTAGE or FIXED")
    if data.discount_type.upper()=="PERCENTAGE" and data.discount_value>100: raise HTTPException(422,"Percentage discount cannot exceed 100")
    if db.query(Coupon).filter(func.upper(Coupon.coupon_code)==code).first(): raise HTTPException(400,"Coupon code already exists")
    c=Coupon(coupon_code=code,discount_type=data.discount_type.upper(),discount_value=data.discount_value,minimum_booking_amount=data.minimum_booking_amount,expiry_date=normalize_event_date(data.expiry_date) if data.expiry_date else None,usage_limit=data.usage_limit,is_active=int(data.is_active))
    db.add(c);db.commit();db.refresh(c)
    return {"id":c.id,"coupon_code":c.coupon_code,"discount_type":c.discount_type,"discount_value":c.discount_value}

@app.post("/payments/{payment_id}/coupon")
def apply_coupon_to_checkout(payment_id:int,data:ApplyCoupon,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.query(Payment).filter(Payment.id==payment_id).first()
    if not p: raise HTTPException(404,"Payment not found")
    b=db.query(Booking).filter(Booking.id==p.booking_id).first()
    if not b or (user.role!="ADMIN" and b.user_id!=user.id): raise HTTPException(403,"You cannot update this checkout")
    if p.payment_status!="PENDING" or b.booking_status!="PENDING_PAYMENT": raise HTTPException(400,"This checkout is no longer pending")
    c=db.query(Coupon).filter(func.upper(Coupon.coupon_code)==data.coupon_code.strip().upper()).first()
    if not c or not c.is_active: raise HTTPException(400,"Invalid or inactive coupon")
    if c.expiry_date and c.expiry_date < datetime.utcnow(): raise HTTPException(400,"Coupon has expired")
    if c.usage_count >= c.usage_limit: raise HTTPException(400,"Coupon usage limit reached")
    subtotal=b.total_price
    if subtotal < c.minimum_booking_amount: raise HTTPException(400,f"Minimum booking amount is ₹{c.minimum_booking_amount:.2f}")
    discount=subtotal*c.discount_value/100 if c.discount_type=="PERCENTAGE" else c.discount_value
    discount=round(min(subtotal,discount),2)
    b.coupon_id=c.id;b.discount_amount=discount;b.final_amount=round(subtotal-discount,2);p.amount=b.final_amount
    db.commit()
    return {"coupon_code":c.coupon_code,"subtotal":subtotal,"discount_amount":discount,"final_amount":b.final_amount,"payment":payment_dict(p)}

@app.get("/payments")
def my_payments(user:User=Depends(current_user),db:Session=Depends(get_db)):
    query=db.query(Payment,Booking).join(Booking,Payment.booking_id==Booking.id)
    if user.role!="ADMIN":
        query=query.filter(Booking.user_id==user.id)
    return [{**payment_dict(payment),"event_title":db.query(Event.title).filter(Event.id==booking.event_id).scalar(),"booking_status":booking.booking_status} for payment,booking in query.order_by(Payment.created_at.desc()).all()]

@app.get("/payments/{payment_id}")
def get_payment(payment_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.query(Payment).filter(Payment.id==payment_id).first()
    if not p: raise HTTPException(404,"Payment not found")
    b=db.query(Booking).filter(Booking.id==p.booking_id).first()
    if not b or (user.role!="ADMIN" and b.user_id!=user.id): raise HTTPException(403,"You cannot view this payment")
    return payment_dict(p)

@app.post("/payments/{payment_id}/simulate")
def simulate_payment(payment_id:int,data:PaymentResult,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.query(Payment).filter(Payment.id==payment_id).first()
    if not p: raise HTTPException(404,"Payment not found")
    b=db.query(Booking).filter(Booking.id==p.booking_id).first()
    if not b or (user.role!="ADMIN" and b.user_id!=user.id): raise HTTPException(403,"You cannot pay for this booking")
    result=data.result.upper()
    if result not in ("SUCCESS","FAILED"):
        raise HTTPException(422,"result must be SUCCESS or FAILED")
    if p.payment_status == "SUCCESS":
        raise HTTPException(400, "This payment has already succeeded")
    if p.payment_status == "FAILED" and b.booking_status == "PAYMENT_FAILED":
        p.payment_status = "PENDING"
        p.transaction_id = None
        db.commit()
    elif p.payment_status != "PENDING":
        raise HTTPException(400, "This payment cannot be processed")
    e=db.query(Event).filter(Event.id==b.event_id).first()
    if result=="SUCCESS":
        coupon=db.query(Coupon).filter(Coupon.id==b.coupon_id).first() if b.coupon_id else None
        coupon_invalid = bool(coupon and (not coupon.is_active or (coupon.expiry_date and coupon.expiry_date < datetime.utcnow()) or coupon.usage_count >= coupon.usage_limit))
        if not e or sync_status(e) != "UPCOMING" or e.available_tickets < b.ticket_quantity or coupon_invalid:
            p.payment_status="FAILED"; p.transaction_id="SIM-FAILED-"+secrets.token_hex(5).upper(); b.booking_status="PAYMENT_FAILED"
            reason = "The coupon is no longer valid." if coupon_invalid else "The event is unavailable or tickets sold out before payment completed."
            db.add(Notification(user_id=b.user_id,title="Payment failed",message=reason,type="PAYMENT",is_read=0))
            db.commit()
            return {"payment":payment_dict(p),"booking_status":b.booking_status,"message":"Payment could not be completed: "+reason}
        result_update = db.query(Event).filter(Event.id == e.id, Event.available_tickets >= b.ticket_quantity, Event.event_status != "CANCELLED").update({Event.available_tickets: Event.available_tickets - b.ticket_quantity}, synchronize_session=False)
        if not result_update:
            p.payment_status="FAILED"; p.transaction_id="SIM-FAILED-"+secrets.token_hex(5).upper(); b.booking_status="PAYMENT_FAILED"
            db.add(Notification(user_id=b.user_id,title="Tickets unavailable",message="Another booking took the remaining tickets. Please choose another event.",type="PAYMENT",is_read=0))
            db.commit()
            raise HTTPException(409, "Tickets are no longer available")
        db.refresh(e)
        p.payment_status="SUCCESS"; p.transaction_id="SIM-"+secrets.token_hex(8).upper()
        b.booking_status="CONFIRMED"
        if b.coupon_id:
            used_coupon=db.query(Coupon).filter(Coupon.id==b.coupon_id).first()
            if used_coupon: used_coupon.usage_count += 1
        code="TKT-"+secrets.token_hex(6).upper()
        db.add(Ticket(booking_id=b.id,ticket_code=code,qr_code_url=f"/tickets/{code}/qr"))
        db.add(Notification(user_id=b.user_id,title="Payment successful",message=f"Payment for {e.title} succeeded and your booking is confirmed.",type="PAYMENT",is_read=0))
        db.add(Notification(user_id=b.user_id,title="Booking confirmed",message=f"Your booking for {e.title} is confirmed.",type="BOOKING",is_read=0))
        db.commit()
        return {"payment":payment_dict(p),"booking":booking_dict(b,e),"ticket_code":code,"message":"Simulated payment successful"}
    p.payment_status="FAILED"; p.transaction_id="SIM-FAILED-"+secrets.token_hex(5).upper(); b.booking_status="PAYMENT_FAILED"
    db.add(Notification(user_id=b.user_id,title="Payment failed",message=f"Payment for booking #{b.id} failed. Please make a new booking.",type="PAYMENT",is_read=0))
    db.commit()
    return {"payment":payment_dict(p),"booking_status":b.booking_status,"message":"Simulated payment failed"}

@app.get("/events/{event_id}/reviews")
def event_reviews(event_id:int,db:Session=Depends(get_db)):
    if not db.query(Event).filter(Event.id==event_id).first(): raise HTTPException(404,"Event not found")
    rows=db.query(Review,User).join(User,Review.user_id==User.id).filter(Review.event_id==event_id).order_by(Review.created_at.desc()).all()
    avg=db.query(func.avg(Review.rating)).filter(Review.event_id==event_id).scalar() or 0
    return {"average_rating":round(float(avg),2),"count":len(rows),"reviews":[{"id":r.id,"user_id":r.user_id,"username":u.username,"rating":r.rating,"review_text":r.review_text,"created_at":r.created_at.isoformat()} for r,u in rows]}

@app.post("/events/{event_id}/reviews")
def submit_review(event_id:int,data:ReviewData,user:User=Depends(require_roles("USER")),db:Session=Depends(get_db)):
    e=db.query(Event).filter(Event.id==event_id).first()
    if not e: raise HTTPException(404,"Event not found")
    if sync_status(e)!="COMPLETED": raise HTTPException(400,"Reviews are available after the event has completed")
    attended=db.query(Booking).filter(Booking.user_id==user.id,Booking.event_id==event_id,Booking.booking_status=="CONFIRMED").first()
    if not attended: raise HTTPException(403,"Only users with a confirmed booking can review this event")
    r=db.query(Review).filter(Review.user_id==user.id,Review.event_id==event_id).first()
    if r:
        r.rating=data.rating;r.review_text=data.review_text
    else:
        r=Review(user_id=user.id,event_id=event_id,rating=data.rating,review_text=data.review_text);db.add(r)
    db.commit();db.refresh(r)
    return {"id":r.id,"event_id":r.event_id,"rating":r.rating,"review_text":r.review_text,"message":"Review saved"}

@app.put("/reviews/{review_id}")
def update_review(review_id:int,data:ReviewData,user:User=Depends(require_roles("USER")),db:Session=Depends(get_db)):
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        raise HTTPException(404, "Review not found")
    if review.user_id != user.id:
        raise HTTPException(403, "You can only edit your own review")
    event = db.query(Event).filter(Event.id == review.event_id).first()
    if not event or sync_status(event) != "COMPLETED":
        raise HTTPException(400, "Reviews can only be edited after the event has completed")
    attended = db.query(Booking).filter(
        Booking.user_id == user.id,
        Booking.event_id == review.event_id,
        Booking.booking_status == "CONFIRMED",
    ).first()
    if not attended:
        raise HTTPException(403, "Only users with a confirmed booking can review this event")
    review.rating = data.rating
    review.review_text = data.review_text
    db.commit()
    db.refresh(review)
    return {"id": review.id, "event_id": review.event_id, "rating": review.rating,
            "review_text": review.review_text, "message": "Review updated"}

@app.delete("/reviews/{review_id}")
def delete_review(review_id:int,user:User=Depends(require_roles("USER")),db:Session=Depends(get_db)):
    r=db.query(Review).filter(Review.id==review_id).first()
    if not r: raise HTTPException(404,"Review not found")
    if r.user_id!=user.id: raise HTTPException(403,"You can only delete your own review")
    db.delete(r);db.commit();return {"message":"Review deleted"}


@app.get("/tickets")
def tickets(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return [{"id":t.id,"booking_id":b.id,"ticket_code":t.ticket_code,"qr_code_url":t.qr_code_url,"event_title":e.title,"event_date":e.event_date.isoformat(),"event_status":sync_status(e),"location":e.location,"ticket_quantity":b.ticket_quantity} for t,b,e in db.query(Ticket,Booking,Event).join(Booking,Ticket.booking_id==Booking.id).join(Event,Booking.event_id==Event.id).filter(Booking.user_id==user.id,Booking.booking_status=="CONFIRMED").all()]
@app.get("/tickets/{ticket_code}/qr")
def qr(ticket_code:str,user:User=Depends(current_user),db:Session=Depends(get_db)):
    ticket=db.query(Ticket).filter(Ticket.ticket_code==ticket_code).first()
    booking=db.query(Booking).filter(Booking.id==ticket.booking_id,Booking.booking_status=="CONFIRMED").first() if ticket else None
    event=db.query(Event).filter(Event.id==booking.event_id).first() if booking else None
    if not ticket or not booking or not event or event.event_status=="CANCELLED":raise HTTPException(404,"Ticket not found")
    if user.role!="ADMIN" and booking.user_id!=user.id:raise HTTPException(403,"You can only view your own ticket QR code")
    img=BytesIO();qrcode.make(ticket_code).save(img,format="PNG");img.seek(0);return StreamingResponse(img,media_type="image/png")
@app.get("/tickets/verify/{ticket_code}")
def verify(ticket_code:str,db:Session=Depends(get_db)):
    ticket=db.query(Ticket).filter(Ticket.ticket_code==ticket_code).first()
    booking=db.query(Booking).filter(Booking.id==ticket.booking_id,Booking.booking_status=="CONFIRMED").first() if ticket else None
    event=db.query(Event).filter(Event.id==booking.event_id).first() if booking else None
    if not ticket or not booking or not event or event.event_status=="CANCELLED":raise HTTPException(404,"Invalid ticket")
    return {"valid":True,"ticket_code":ticket_code}
@app.get("/notifications")
def notifications(user:User=Depends(current_user),db:Session=Depends(get_db)):
    now=datetime.utcnow(); soon=now+timedelta(hours=24)
    upcoming=db.query(Booking,Event).join(Event,Booking.event_id==Event.id).filter(Booking.user_id==user.id,Booking.booking_status=="CONFIRMED",Event.event_date>=now,Event.event_date<=soon,Event.event_status!="CANCELLED").all()
    for b,e in upcoming:
        title=f"Event reminder: {e.title}"
        exists=db.query(Notification).filter(Notification.user_id==user.id,Notification.title==title).first()
        if not exists: db.add(Notification(user_id=user.id,title=title,message=f"{e.title} starts within 24 hours at {e.location}.",type="EVENT",is_read=0))
    db.commit()
    return [{"id":n.id,"title":n.title,"message":n.message,"type":n.type,"notification_type":n.type,"is_read":bool(n.is_read),"created_at":n.created_at.isoformat()} for n in db.query(Notification).filter(Notification.user_id==user.id).order_by(Notification.created_at.desc()).all()]
@app.patch("/notifications/{notification_id}/read")
def read_notification(notification_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    n=db.query(Notification).filter(Notification.id==notification_id,Notification.user_id==user.id).first()
    if not n:raise HTTPException(404,"Notification not found")
    n.is_read=1;db.commit();return {"message":"Notification marked as read"}

from fastapi import status
from fastapi.responses import JSONResponse
from fastapi import WebSocket

class AvailabilityHub:
    def __init__(self): self.connections = {}
    async def connect(self, event_id, ws):
        await ws.accept(); self.connections.setdefault(event_id, set()).add(ws)
    def disconnect(self, event_id, ws):
        self.connections.get(event_id, set()).discard(ws)
    async def broadcast(self, event_id, payload):
        for ws in list(self.connections.get(event_id, set())):
            try: await ws.send_json(payload)
            except Exception: self.disconnect(event_id, ws)

availability_hub = AvailabilityHub()

@app.websocket("/ws/events/{event_id}/availability")
async def live_availability(websocket: WebSocket, event_id: int):
    await availability_hub.connect(event_id, websocket)
    db = SessionLocal()
    try:
        while True:
            event = db.query(Event).filter(Event.id == event_id).first()
            if not event:
                await websocket.send_json({"error": "Event not found"}); break
            await websocket.send_json({"event_id": event.id, "available_tickets": event.available_tickets, "event_status": sync_status(event)})
            try: await asyncio.wait_for(websocket.receive_text(), timeout=3)
            except asyncio.TimeoutError: pass
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        availability_hub.disconnect(event_id, websocket); db.close()

@app.get("/events/{event_id}/availability")
def event_availability(event_id: int, db: Session = Depends(get_db)):
    e = db.query(Event).filter(Event.id == event_id).first()
    if not e: raise HTTPException(404, "Event not found")
    return {"event_id": e.id, "available_tickets": e.available_tickets, "event_status": sync_status(e)}

@app.get("/recommendations")
def recommendations(user: User = Depends(current_user), db: Session = Depends(get_db)):
    viewed = [r[0] for r in db.query(EventView.event_id).filter(EventView.user_id == user.id).order_by(EventView.created_at.desc()).limit(20).all()]
    booked_categories = [r[0] for r in db.query(Event.category).join(Booking, Booking.event_id == Event.id).filter(Booking.user_id == user.id, Booking.booking_status == "CONFIRMED").all()]
    viewed_categories = [r[0] for r in db.query(Event.category).filter(Event.id.in_(viewed)).all()] if viewed else []
    prefs = set(booked_categories + viewed_categories)
    profile = db.query(UserProfile).filter(UserProfile.user_id == user.id).first()
    preferred_location = (profile.location or "").strip().lower() if profile else ""
    q = db.query(Event).filter(Event.event_status == "UPCOMING", Event.available_tickets > 0)
    all_events = q.all()
    popularity = dict(db.query(Booking.event_id, func.coalesce(func.sum(Booking.ticket_quantity), 0)).filter(Booking.booking_status == "CONFIRMED").group_by(Booking.event_id).all())
  
    all_events.sort(key=lambda e: (e.category in prefs, bool(preferred_location and preferred_location in e.location.lower()), popularity.get(e.id, 0), -e.ticket_price), reverse=True)
    trending = sorted(all_events, key=lambda e: (popularity.get(e.id, 0), e.event_date), reverse=True)
    return {"recommended": [event_dict(e) for e in all_events[:8]], "trending": [event_dict(e) for e in trending[:8]]}

@app.post("/events/{event_id}/view")
def track_event_view(event_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not db.query(Event).filter(Event.id == event_id).first(): raise HTTPException(404, "Event not found")
    db.add(EventView(user_id=user.id, event_id=event_id)); db.commit()
    return {"message": "Event view recorded"}

@app.get("/wishlist")
def get_wishlist(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(Wishlist, Event).join(Event, Event.id == Wishlist.event_id).filter(Wishlist.user_id == user.id).order_by(Wishlist.created_at.desc()).all()
    return [{**event_dict(e), "wishlist_id": w.id, "saved_at": w.created_at.isoformat()} for w,e in rows]

@app.post("/wishlist/{event_id}")
def add_wishlist(event_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not db.query(Event).filter(Event.id == event_id).first(): raise HTTPException(404, "Event not found")
    row = db.query(Wishlist).filter(Wishlist.user_id == user.id, Wishlist.event_id == event_id).first()
    if row: return {"message": "Event is already in your wishlist"}
    db.add(Wishlist(user_id=user.id, event_id=event_id)); db.commit()
    return {"message": "Event saved to wishlist"}

@app.delete("/wishlist/{event_id}")
def remove_wishlist(event_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.query(Wishlist).filter(Wishlist.user_id == user.id, Wishlist.event_id == event_id).first()
    if not row: raise HTTPException(404, "Wishlist item not found")
    db.delete(row); db.commit(); return {"message": "Event removed from wishlist"}

@app.get("/events/{event_id}/updates")
def get_event_updates(event_id: int, db: Session = Depends(get_db)):
    if not db.query(Event).filter(Event.id == event_id).first(): raise HTTPException(404, "Event not found")
    rows = db.query(EventUpdate, User).outerjoin(User, User.id == EventUpdate.user_id).filter(EventUpdate.event_id == event_id).order_by(EventUpdate.created_at.desc()).all()
    return [{"id": u.id, "event_id": u.event_id, "message": u.message, "created_at": u.created_at.isoformat(), "posted_by": usr.username if usr else "SmartEvent"} for u,usr in rows]

@app.post("/events/{event_id}/updates")
def post_event_update(event_id: int, data: EventUpdateData, user: User = Depends(require_roles("ORGANIZER", "ADMIN")), db: Session = Depends(get_db)):
    e = db.query(Event).filter(Event.id == event_id).first()
    if not e: raise HTTPException(404, "Event not found")
    if user.role != "ADMIN" and e.organizer_id != user.id: raise HTTPException(403, "You can only post updates for your own events")
    row = EventUpdate(event_id=event_id, message=data.message, user_id=user.id); db.add(row)
    notify_bookers(db, e, "Event announcement", data.message); db.commit(); db.refresh(row)
    return {"id": row.id, "event_id": row.event_id, "message": row.message, "created_at": row.created_at.isoformat(), "posted_by": user.username}

@app.put("/auth/profile")
def update_profile(data: ProfileUpdate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    user.username = data.username
    profile = db.query(UserProfile).filter(UserProfile.user_id == user.id).first()
    if not profile: profile = UserProfile(user_id=user.id); db.add(profile)
    profile.location = data.location
    db.commit(); db.refresh(user)
    return {"id": user.id, "username": user.username, "email": user.email, "role": user.role, "location": profile.location, "profile_picture": profile.profile_picture}

@app.get("/auth/profile/summary")
def profile_summary(user: User = Depends(current_user), db: Session = Depends(get_db)):
    bookings = db.query(Booking).filter(Booking.user_id == user.id).all()
    profile = db.query(UserProfile).filter(UserProfile.user_id == user.id).first()
    return {"username": user.username, "email": user.email, "role": user.role, "location": profile.location if profile else "", "profile_picture": profile.profile_picture if profile else None, "total_bookings": len(bookings), "confirmed_bookings": sum(b.booking_status == "CONFIRMED" for b in bookings), "tickets_booked": sum(b.ticket_quantity for b in bookings if b.booking_status == "CONFIRMED"), "wishlist_count": db.query(Wishlist).filter(Wishlist.user_id == user.id).count()}

@app.post("/auth/profile/picture")
def upload_profile_picture(file: UploadFile = File(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    if file.content_type not in ("image/png", "image/jpeg", "image/webp"): raise HTTPException(400, "Upload a PNG, JPG, or WEBP image")
    data = file.file.read(2 * 1024 * 1024 + 1)
    if len(data) > 2 * 1024 * 1024: raise HTTPException(400, "Image must be 2 MB or smaller")
    
    try:
        from PIL import Image
        image = Image.open(BytesIO(data))
        if image.format not in ("PNG", "JPEG", "WEBP"):
            raise ValueError("Unsupported image format")
        image.verify()
    except Exception:
        raise HTTPException(400, "The uploaded file is not a valid PNG, JPG, or WEBP image")
    import base64
    profile = db.query(UserProfile).filter(UserProfile.user_id == user.id).first()
    if not profile: profile = UserProfile(user_id=user.id); db.add(profile)
    profile.profile_picture = "data:" + file.content_type + ";base64," + base64.b64encode(data).decode()
    db.commit(); return {"profile_picture": profile.profile_picture}

@app.post("/assistant/chat")
def assistant_chat(data: ChatData, user: User = Depends(current_user), db: Session = Depends(get_db)):
    msg = data.message.lower()
    if any(k in msg for k in ("my booking", "my reservation", "booking status", "my tickets")):
        rows = db.query(Booking, Event).join(Event, Booking.event_id == Event.id).filter(Booking.user_id == user.id).order_by(Booking.created_at.desc()).limit(10).all()
        if not rows: answer = "You do not have any bookings yet. Browse events and select one to book tickets."
        else: answer = "Your recent bookings: " + "; ".join(f"{e.title}: {b.booking_status}, {b.ticket_quantity} ticket(s), ₹{(b.final_amount or b.total_price):.2f}" for b,e in rows)
    elif any(k in msg for k in ("ticket issue", "ticket problem", "qr", "help", "support", "payment issue")):
        answer = "For ticket help, open Tickets to view your QR code. For payment problems, open Bookings and check the payment status. Payments in this project are simulated. If the issue remains, share the booking ID with the event organizer."
    elif any(k in msg for k in ("trending", "popular")):
        rows = db.query(Event).filter(Event.event_status == "UPCOMING", Event.available_tickets > 0).all()
        counts = dict(db.query(Booking.event_id, func.coalesce(func.sum(Booking.ticket_quantity),0)).filter(Booking.booking_status == "CONFIRMED").group_by(Booking.event_id).all())
        rows.sort(key=lambda e: counts.get(e.id,0), reverse=True)
        answer = "Trending events: " + ("; ".join(f"{e.title} ({e.category}) in {e.location}, ₹{e.ticket_price:g}" for e in rows[:5]) if rows else "No upcoming events are available right now.")
    else:
        rows = db.query(Event).filter(Event.event_status == "UPCOMING", Event.available_tickets > 0).all()
        for category in ("music", "tech", "sport", "business", "art"):
            if category in msg: rows = [e for e in rows if category in e.category.lower() or category in e.title.lower()]
        loc = next((word.strip("?.,") for word in msg.split() if word.lower() in ("hyderabad", "gachibowli", "hitex", "hicc")), None)
        if not loc and any(k in msg for k in ("near me", "nearby", "my area")):
            prof = db.query(UserProfile).filter(UserProfile.user_id == user.id).first()
            loc = prof.location if prof and prof.location else None
        if loc: rows = [e for e in rows if loc.lower() in e.location.lower()]
        if "weekend" in msg:
            today = datetime.utcnow().date(); end = today + timedelta(days=(5-today.weekday()) % 7 + 2)
            rows = [e for e in rows if today <= e.event_date.date() <= end]
        answer = "Here are events that may match: " + ("; ".join(f"{e.title} — {e.category}, {e.location}, {e.event_date.strftime('%d %b %Y %H:%M')}, ₹{e.ticket_price:g}" for e in rows[:6]) if rows else "I couldn't find a matching upcoming event. Try another category, date, or location.")

    return {"reply": answer, "assistant": "SmartEvent Assistant"}

Base.metadata.create_all(bind=engine)
