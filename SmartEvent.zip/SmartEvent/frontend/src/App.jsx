import { useEffect, useState } from "react";
import api, { authHeaders } from "./api";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import { LoginPage, RegisterPage } from "./pages/AuthPages";
import HomePage from "./pages/HomePage";
import EventDetailsPage from "./pages/EventDetailsPage";
import BookingConfirmationPage from "./pages/BookingConfirmationPage";
import BookingHistoryPage from "./pages/BookingHistoryPage";
import TicketsPage from "./pages/TicketsPage";
import NotificationsPage from "./pages/NotificationsPage";
import Phase2Page from "./pages/Phase2Page";
import PaymentPage from "./pages/PaymentPage";
import Phase4Page from "./pages/Phase4Page";
import ChatAssistant from "./components/ChatAssistant";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("user") || "null"));
  const [page, setPage] = useState(token ? "home" : "login");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [confirmation, setConfirmation] = useState(null);
  const [checkout, setCheckout] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!token) return;
    api.get("/auth/profile", { headers: authHeaders() }).then((response) => {
      setUser(response.data);
      localStorage.setItem("user", JSON.stringify(response.data));
    }).catch(() => logout());
  }, [token]);

  function showMessage(text) {
    setMessage(text);
    setError("");
  }

  function showError(text) {
    setError(text);
    setMessage("");
  }

  function saveLogin(data) {
    localStorage.setItem("token", data.access_token);
    localStorage.setItem("user", JSON.stringify(data.user));
    setToken(data.access_token);
    setUser(data.user);
    setPage("home");
  }

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setToken(null);
    setUser(null);
    setPage("login");
    setSelectedEvent(null);
  }

  async function openEvent(id) {
    try {
      const response = await api.get(`/events/${id}`);
      setSelectedEvent(response.data);
      setPage("details");
    } catch {
      showError("Could not open event.");
    }
  }

  function onBooked(data) {
    setCheckout(data);
    setPage("payment");
  }
  function retryPayment() {
    if (!confirmation?.payment?.id || !confirmation?.booking) return;
    setCheckout({
      booking: confirmation.booking,
      payment: confirmation.payment,
      subtotal: confirmation.booking.total_price,
      discount_amount: confirmation.booking.discount_amount || 0,
      final_amount: confirmation.booking.final_amount ?? confirmation.booking.total_price,
    });
    setPage("payment");
  }

  function onPaid(data) {
    setConfirmation({
      booking: data.booking || (checkout?.booking ? { ...checkout.booking, booking_status: data.booking_status || checkout.booking.booking_status } : null),
      ticket_code: data.ticket_code || null,
      payment: data.payment,
      message: data.message || "",
      booking_status: data.booking_status || data.booking?.booking_status,
    });
    setCheckout(null);
    setPage("confirmation");
  }

  async function loadUnreadCount() {
    if (!token) return;
    try {
      const response = await api.get("/notifications", { headers: authHeaders() });
      setUnreadCount(response.data.filter((item) => !item.is_read).length);
    } catch {
      // Notification count is optional; do not stop the application if it fails.
    }
  }

  useEffect(() => {
    loadUnreadCount();
  }, [token, page]);

  if (!token) {
    return (
      <>
        {message && <div className="message">{message}</div>}
        {error && <div className="error">{error}</div>}
        {page === "register" ? (
          <RegisterPage goLogin={() => setPage("login")} showMessage={showMessage} showError={showError} />
        ) : (
          <LoginPage onLogin={saveLogin} goRegister={() => setPage("register")} showMessage={showMessage} showError={showError} />
        )}
      </>
    );
  }

  function renderPage() {
    switch (page) {
      case "home":
        return <HomePage onViewEvent={openEvent} showError={showError} />;
      case "details":
        return <EventDetailsPage event={selectedEvent} userRole={user?.role} userId={user?.id} onBack={() => setPage("home")} onBooked={onBooked} showMessage={showMessage} showError={showError} />;
      case "payment":
        return <PaymentPage checkout={checkout} onPaid={onPaid} onBack={() => setPage("details")} showError={showError} />;
      case "confirmation":
        return <BookingConfirmationPage booking={confirmation?.booking} ticketCode={confirmation?.ticket_code} payment={confirmation?.payment} message={confirmation?.message} bookingStatus={confirmation?.booking_status} goTickets={() => setPage("tickets")} goHome={() => setPage("home")} retryPayment={retryPayment} />;
      case "bookings":
        return <BookingHistoryPage showError={showError} showMessage={showMessage} />;
      case "tickets":
        return <TicketsPage showError={showError} showMessage={showMessage} />;
      case "notifications":
        return <NotificationsPage showError={showError} onChanged={loadUnreadCount} />;
      case "wishlist":
        return <Phase4Page mode="wishlist" user={user} onViewEvent={openEvent} showError={showError} showMessage={showMessage} />;
      case "profile":
        return <Phase4Page mode="profile" user={user} onUserUpdated={(updated) => { setUser(updated); localStorage.setItem("user", JSON.stringify(updated)); }} showError={showError} showMessage={showMessage} />;
      case "organizer":
        return <Phase2Page mode="organizer" user={user} showError={showError} showMessage={showMessage} />;
      case "admin":
        return <Phase2Page mode="admin" user={user} showError={showError} showMessage={showMessage} />;
      default:
        return <HomePage onViewEvent={openEvent} showError={showError} />;
    }
  }

  return (
    <div>
      <Navbar user={user} page={page} setPage={setPage} onLogout={logout} unreadCount={unreadCount} onNotificationsChanged={loadUnreadCount} />
      {message && <div className="message">{message}</div>}
      {error && <div className="error">{error}</div>}
      <ProtectedRoute token={token}>{renderPage()}</ProtectedRoute>
      <ChatAssistant />
    </div>
  );
}

export default App;
