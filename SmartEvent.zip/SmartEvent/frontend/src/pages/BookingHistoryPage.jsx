import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";

function BookingHistoryPage({ showError, showMessage }) {
  const [bookings, setBookings] = useState([]);

  async function loadBookings() {
    try { const response = await api.get("/bookings", { headers: authHeaders() }); setBookings(response.data); }
    catch { showError("Could not load booking history."); }
  }
  useEffect(() => { loadBookings(); }, []);

  async function cancelBooking(booking) {
    if (!window.confirm(`Cancel your booking for “${booking.event_title}”?`)) return;
    try {
      await api.post(`/bookings/${booking.id}/cancel`, {}, { headers: authHeaders() });
      showMessage("Booking cancelled. The tickets are available again.");
      await loadBookings();
    } catch (error) { showError(error.response?.data?.detail || "Could not cancel booking."); }
  }

  return (
    <main className="container">
      <h1>Booking History</h1>
      {bookings.map((booking) => (
        <div className="card booking" key={booking.id}>
          <h3>{booking.event_title}</h3>
          <p>{new Date(booking.event_date).toLocaleString()} | {booking.location}</p>
          {booking.event_status === "CANCELLED" && <p className="cancellation-notice">This event has been cancelled. Check your notifications for details.</p>}
          <p>Tickets: {booking.ticket_quantity}</p>
          <p>Subtotal: ₹{Number(booking.total_price || 0).toFixed(2)}</p><p>Discount: − ₹{Number(booking.discount_amount || 0).toFixed(2)}</p><p>Final amount: ₹{Number(booking.final_amount ?? booking.total_price ?? 0).toFixed(2)}</p>
          <p>Status: <strong>{booking.booking_status}</strong></p>
          {booking.booking_status === "CONFIRMED" && booking.event_status !== "CANCELLED" && new Date(booking.event_date) > new Date() && <button className="danger" onClick={() => cancelBooking(booking)}>Cancel booking</button>}
        </div>
      ))}
      {!bookings.length && <p>No bookings yet.</p>}
    </main>
  );
}

export default BookingHistoryPage;
