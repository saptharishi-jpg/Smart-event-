import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";

function EventDetailsPage({ event, userRole, userId, onBack, onBooked, showMessage, showError }) {
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);
  const [reviews, setReviews] = useState({ average_rating: 0, count: 0, reviews: [] });
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState("");
  const [editingReviewId, setEditingReviewId] = useState(null);
  const [updates, setUpdates] = useState([]);
  const [announcement, setAnnouncement] = useState("");
  const [available, setAvailable] = useState(event?.available_tickets ?? 0);
  async function loadReviews() {
    try { setReviews((await api.get(`/events/${event.id}/reviews`)).data); } catch { /* reviews are optional */ }
  }
  async function loadUpdates() { try { setUpdates((await api.get(`/events/${event.id}/updates`)).data); } catch { /* live updates are optional */ } }
  useEffect(() => {
    loadReviews(); loadUpdates(); setAvailable(event?.available_tickets ?? 0);
    if (event?.id) api.post(`/events/${event.id}/view`, {}, { headers: authHeaders() }).catch(() => {});
    const timer = setInterval(async () => { try { const r = await api.get(`/events/${event.id}/availability`); setAvailable(r.data.available_tickets); } catch {} loadUpdates(); }, 4000);
    return () => clearInterval(timer);
  }, [event?.id]);
  async function postAnnouncement(e) { e.preventDefault(); try { await api.post(`/events/${event.id}/updates`, { message: announcement }, { headers: authHeaders() }); setAnnouncement(""); showMessage("Announcement posted."); await loadUpdates(); } catch (err) { showError(err.response?.data?.detail || "Could not post announcement."); } }
  async function book() {
    setLoading(true);
    try {
      const response = await api.post("/bookings", { event_id: event.id, ticket_quantity: quantity }, { headers: authHeaders() });
      onBooked(response.data);
    } catch (error) { showError(error.response?.data?.detail || "Could not create checkout."); }
    finally { setLoading(false); }
  }
  async function deleteReview(id) {
    try {
      await api.delete(`/reviews/${id}`, { headers: authHeaders() });
      showMessage("Your review was deleted."); await loadReviews();
    } catch (error) { showError(error.response?.data?.detail || "Could not delete review."); }
  }
  async function submitReview(e) {
    e.preventDefault();
    try {
      const payload = { rating: Number(rating), review_text: reviewText };
      if (editingReviewId) {
        await api.put(`/reviews/${editingReviewId}`, payload, { headers: authHeaders() });
        showMessage("Your review was updated.");
      } else {
        await api.post(`/events/${event.id}/reviews`, payload, { headers: authHeaders() });
        showMessage("Your review was saved.");
      }
      setReviewText(""); setEditingReviewId(null); await loadReviews();
    } catch (error) { showError(error.response?.data?.detail || "Could not submit review. Reviews are available to confirmed attendees after the event."); }
  }
  const subtotal = Number(event.ticket_price) * Number(quantity);
  return <main className="container">
    <button className="secondary" onClick={onBack}>← Back to events</button>
    <div className="details card event-detail-card">
      <div className="event-box large">{event.banner_image ? <img src={event.banner_image} alt={event.title}/> : event.category}</div>
      <div>
        <p className="eyebrow">{event.category} · SMART EVENT</p><h1>{event.title}</h1><p>{event.description}</p>
        <p><strong>Location:</strong> {event.location}</p>
        <p><strong>Date:</strong> {new Date(event.event_date).toLocaleString()}</p>
        <p><strong>Price:</strong> ₹{Number(event.ticket_price).toFixed(2)}</p>
        <p><strong>Live tickets available:</strong> {available}</p>
        <p><strong>Status:</strong> <span className={`status ${event.event_status?.toLowerCase()}`}>{event.event_status}</span></p>
        <p className="rating-summary">★ {Number(reviews.average_rating || 0).toFixed(1)} <span>({reviews.count} reviews)</span></p>
        {event.event_status === "CANCELLED" ? <div className="cancellation-notice">This event has been cancelled. Ticket sales are closed.</div> : userRole === "USER" ? <>
          <label>Tickets <input className="quantity" type="number" min="1" max={Math.min(10,available)} value={quantity} onChange={e=>setQuantity(Number(e.target.value))}/></label>
          <div className="price-breakdown"><p>Subtotal: ₹{subtotal.toFixed(2)}</p><h3>Continue to checkout to apply a coupon</h3></div>
          <button onClick={book} disabled={loading || available === 0 || event.event_status !== "UPCOMING"}>{available === 0 ? "Sold out" : loading ? "Preparing checkout…" : "Continue to payment"}</button>
          <small className="muted">Payment is simulated for this learning project. No real money is charged.</small>
        </> : <p>Sign in with a USER account to book tickets.</p>}
      </div>
    </div>
    <section className="card live-updates"><div className="section-heading"><div><p className="eyebrow">ANNOUNCEMENTS</p><h2>Live Updates</h2></div><span>Updates refresh automatically</span></div>
      {userRole === "ORGANIZER" || userRole === "ADMIN" ? <form className="filters" onSubmit={postAnnouncement}><input value={announcement} onChange={e=>setAnnouncement(e.target.value)} placeholder="Post an event announcement" maxLength="2000" required/><button>Post update</button></form> : null}
      {updates.length ? updates.map(item=><article className="notification unread" key={item.id}><strong>📢 {item.posted_by}</strong><p>{item.message}</p><small>{new Date(item.created_at).toLocaleString()}</small></article>) : <p className="muted">No announcements yet.</p>}
    </section>
    <section className="reviews-section">
      <div className="section-heading"><div><p className="eyebrow">COMMUNITY FEEDBACK</p><h2>Event reviews</h2></div><span>★ {Number(reviews.average_rating || 0).toFixed(1)} average</span></div>
      {event.event_status === "COMPLETED" && userRole === "USER" && <form className="card review-form" onSubmit={submitReview}>
        <h3>{editingReviewId ? "Edit your review" : "Share your experience"}</h3><label>Rating <select value={rating} onChange={e=>setRating(e.target.value)}>{[5,4,3,2,1].map(n=><option key={n} value={n}>{'★'.repeat(n)} ({n}/5)</option>)}</select></label>
        <textarea rows="3" maxLength="2000" placeholder="What did you think of this event?" value={reviewText} onChange={e=>setReviewText(e.target.value)}/>
        <div className="row-actions"><button>{editingReviewId ? "Save changes" : "Submit review"}</button>{editingReviewId && <button type="button" className="secondary" onClick={() => { setEditingReviewId(null); setRating(5); setReviewText(""); }}>Cancel edit</button>}</div>
      </form>}
      {reviews.reviews.map(r=><article className="card review-card" key={r.id}><div className="review-top"><strong>{r.username}</strong><span>{"★".repeat(r.rating)}{"☆".repeat(5-r.rating)}</span></div><p>{r.review_text || "Rated this event."}</p><small className="muted">{new Date(r.created_at).toLocaleDateString()}</small>{Number(r.user_id)===Number(userId) && <div className="row-actions"><button className="secondary small-button" onClick={()=>{setEditingReviewId(r.id);setRating(r.rating);setReviewText(r.review_text || "");window.scrollTo({top:0,behavior:"smooth"});}}>Edit my review</button><button className="danger small-button" onClick={()=>deleteReview(r.id)}>Delete my review</button></div>}</article>)}
      {!reviews.reviews.length && <p className="muted">No reviews yet. Reviews can be submitted by users with a confirmed booking after the event.</p>}
    </section>
  </main>;
}
export default EventDetailsPage;
