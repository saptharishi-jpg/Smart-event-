import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";
import EventCard from "../components/EventCard";

export default function Phase4Page({ mode, user, onUserUpdated, onViewEvent, showMessage, showError }) {
  const [items, setItems] = useState([]);
  const [summary, setSummary] = useState(null);
  const [profile, setProfile] = useState({ username: user?.username || "", location: "" });
  const [loading, setLoading] = useState(false);
  async function load() {
    setLoading(true);
    try {
      if (mode === "wishlist") setItems((await api.get("/wishlist", { headers: authHeaders() })).data);
      else {
        const r = await api.get("/auth/profile/summary", { headers: authHeaders() });
        setSummary(r.data); setProfile({ username: r.data.username || "", location: r.data.location || "" });
      }
    } catch (e) { showError(e.response?.data?.detail || "Could not load this page."); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [mode]);
  async function remove(id) {
    try { await api.delete(`/wishlist/${id}`, { headers: authHeaders() }); setItems(old => old.filter(e => e.id !== id)); showMessage("Removed from wishlist."); }
    catch (e) { showError(e.response?.data?.detail || "Could not remove event."); }
  }
  async function saveProfile(e) {
    e.preventDefault();
    try { await api.put("/auth/profile", profile, { headers: authHeaders() }); showMessage("Profile updated."); load(); }
    catch (e) { showError(e.response?.data?.detail || "Could not update profile."); }
  }
  async function upload(e) {
    const file = e.target.files?.[0]; if (!file) return;
    const data = new FormData(); data.append("file", file);
    try { await api.post("/auth/profile/picture", data, { headers: authHeaders() }); showMessage("Profile picture updated."); load(); }
    catch (err) { showError(err.response?.data?.detail || "Could not upload image."); }
  }
  if (mode === "wishlist") return <main className="container"><div className="page-heading"><div><p className="eyebrow">SAVED FOR LATER</p><h1>My Wishlist</h1></div><span>{items.length} saved events</span></div>
    {loading ? <p>Loading wishlist…</p> : items.length ? <div className="event-grid">{items.map(event => <div className="card" key={event.id}><EventCard event={event} onView={onViewEvent}/><button className="danger" onClick={() => remove(event.id)}>Remove</button></div>)}</div> : <div className="card empty-state"><h3>Your wishlist is empty</h3><p>Save events from the event cards to find them here.</p></div>}
  </main>;
  return <main className="container"><div className="page-heading"><div><p className="eyebrow">YOUR ACCOUNT</p><h1>My Profile</h1></div></div>
    <div className="metrics-grid">{[["Bookings",summary?.total_bookings],["Confirmed bookings",summary?.confirmed_bookings],["Tickets booked",summary?.tickets_booked],["Saved events",summary?.wishlist_count]].map(([label,value])=><div className="card metric" key={label}><span>{label}</span><strong>{value ?? "—"}</strong></div>)}</div>
    <form className="card event-form" onSubmit={saveProfile}><h2 className="wide">Edit profile</h2>{summary?.profile_picture && <div className="wide profile-picture-preview"><img src={summary.profile_picture} alt="Your profile" style={{width:96,height:96,objectFit:"cover",borderRadius:"50%"}}/></div>}<label>Username<input value={profile.username} minLength="2" maxLength="50" required onChange={e=>setProfile({...profile,username:e.target.value})}/></label><label>Email<input value={summary?.email || ""} disabled/></label><label className="wide">Location<input placeholder="Your city or location" value={profile.location} onChange={e=>setProfile({...profile,location:e.target.value})}/></label><div className="wide"><button>Save profile</button></div><label className="wide">Profile picture (optional)<input type="file" accept="image/png,image/jpeg,image/webp" onChange={upload}/><small className="muted">PNG, JPG or WEBP; maximum 2 MB.</small></label></form>
  </main>;
}
