import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";

const blankEvent = { title: "", description: "", category: "Tech", location: "", event_date: "", ticket_price: 0, available_tickets: 100, banner_image: "" };
const request = (url, options = {}) => api({ url, ...options, headers: { ...authHeaders(), ...(options.headers || {}) } });
function Metric({ label, value }) { return <div className="metric card"><span>{label}</span><strong>{value}</strong></div>; }
function Table({ columns, rows, empty = "No records found." }) {
  return rows.length ? <div className="table-wrap"><table><thead><tr>{columns.map(c => <th key={c.key}>{c.label}</th>)}</tr></thead><tbody>{rows.map((row, i) => <tr key={row.id ?? row.event_id ?? i}>{columns.map(c => <td key={c.key}>{c.render ? c.render(row) : row[c.key] ?? "—"}</td>)}</tr>)}</tbody></table></div> : <p>{empty}</p>;
}

export default function Phase2Page({ mode, user, showError, showMessage }) {
  const [tab, setTab] = useState(mode === "admin" ? "analytics" : "overview");
  const [analytics, setAnalytics] = useState(null); const [events, setEvents] = useState([]); const [bookings, setBookings] = useState([]); const [users, setUsers] = useState([]);
  const [editing, setEditing] = useState(null); const [form, setForm] = useState(blankEvent); const [range, setRange] = useState({ start_date: "", end_date: "" });
  const admin = mode === "admin";
  async function load(filters = range) {
    try {
      const [a, e, b] = await Promise.all([request(admin ? "/admin/analytics" : "/organizer/analytics", { params: admin ? Object.fromEntries(Object.entries(filters).filter(([,v]) => v)) : {} }), request(admin ? "/admin/events" : "/organizer/events"), request(admin ? "/admin/bookings" : "/organizer/bookings")]);
      setAnalytics(a.data); setEvents(e.data); setBookings(b.data);
      if (admin) setUsers((await request("/admin/users")).data);
    } catch (error) { showError(error.response?.data?.detail || "Could not load dashboard."); }
  }
  useEffect(() => { load(); }, [mode]);
  function startEdit(event) {
    setEditing(event?.id ?? "new");
    setForm(event ? { ...event, event_date: new Date(event.event_date).toISOString().slice(0, 16) } : blankEvent);
    setTab("form");
  }
  async function saveEvent(e) {
    e.preventDefault();
    try {
      const payload = { ...form, event_date: new Date(form.event_date).toISOString(), ticket_price: Number(form.ticket_price), available_tickets: Number(form.available_tickets), banner_image: form.banner_image || null };
      await request(editing === "new" ? "/events" : `/events/${editing}`, { method: editing === "new" ? "POST" : "PUT", data: payload });
      showMessage(editing === "new" ? "Event created." : "Event updated. Bookers were notified."); setTab("events"); await load();
    } catch (error) { showError(error.response?.data?.detail || "Could not save event."); }
  }
  async function cancel(event) {
    if (!window.confirm(`Cancel “${event.title}”? Bookers will be notified.`)) return;
    try { await request(`/events/${event.id}/cancel`, { method: "POST" }); showMessage("Event cancelled. Bookers were notified."); await load(); }
    catch (error) { showError(error.response?.data?.detail || "Could not cancel event."); }
  }
  async function cancelPlatformBooking(booking) {
    if (!window.confirm(`Cancel ${booking.username}'s booking for “${booking.event_title}”?`)) return;
    try {
      await request(`/bookings/${booking.id}/cancel`, { method: "POST" });
      showMessage("Booking cancelled and the booker was notified.");
      await load();
    } catch (error) { showError(error.response?.data?.detail || "Could not cancel booking."); }
  }
  async function changeRole(target, role) {
    try { await request(`/admin/users/${target.id}/role`, { method: "PATCH", data: { role } }); showMessage(`${target.username}'s role updated.`); await load(); }
    catch (error) { showError(error.response?.data?.detail || "Could not update role."); }
  }
  const nav = admin ? [["analytics", "Analytics"], ["users", "Users"], ["events", "Events"], ["bookings", "Bookings"]] : [["overview", "Overview"], ["events", "Manage events"], ["bookings", "Bookings"]];
  const total = analytics?.totals || analytics || {};
  return <main className="container">
    <div className="page-heading"><div><p className="eyebrow">{admin ? "PLATFORM ADMINISTRATION" : "ORGANIZER WORKSPACE"}</p><h1>{admin ? "Admin Dashboard" : `Welcome, ${user?.username}`}</h1></div><button onClick={() => startEdit(null)}>Create event</button></div>
    <div className="dashboard-tabs">{nav.map(([key, label]) => <button className={tab === key ? "active" : ""} key={key} onClick={() => setTab(key)}>{label}</button>)}</div>
    {tab === "form" && <section className="card"><div className="page-heading"><h2>{editing === "new" ? "Create event" : "Edit event"}</h2><button className="secondary" onClick={() => setTab("events")}>Back</button></div><form className="event-form" onSubmit={saveEvent}>
      <label>Title<input required minLength="3" maxLength="150" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label>
      <label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{["Tech","Music","Sports","Business","Arts","Community","Other"].map(x=><option key={x}>{x}</option>)}</select></label>
      <label>Location<input required value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/></label>
      <label>Date and time<input required type="datetime-local" value={form.event_date} onChange={e=>setForm({...form,event_date:e.target.value})}/></label>
      <label>Ticket price (₹)<input required type="number" min="0" step="0.01" value={form.ticket_price} onChange={e=>setForm({...form,ticket_price:e.target.value})}/></label>
      <label>Ticket capacity<input required type="number" min="1" value={form.available_tickets} onChange={e=>setForm({...form,available_tickets:e.target.value})}/></label>
      <label className="wide">Banner image URL (optional)<input value={form.banner_image || ""} onChange={e=>setForm({...form,banner_image:e.target.value})}/></label>
      <label className="wide">Description<textarea required minLength="5" rows="5" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>
      <button className="wide">Save event</button>
    </form></section>}
    {(tab === "overview" || tab === "analytics") && <>
      {admin && <div className="filters date-filter"><label>From<input type="date" value={range.start_date} onChange={e=>setRange({...range,start_date:e.target.value})}/></label><label>To<input type="date" value={range.end_date} onChange={e=>setRange({...range,end_date:e.target.value})}/></label><button onClick={()=>load(range)}>Apply dates</button><button className="secondary" onClick={()=>{const empty={start_date:"",end_date:""};setRange(empty);load(empty)}}>Clear</button></div>}
      <div className="metrics-grid">{admin ? <><Metric label="Registered users" value={analytics?.total_users ?? 0}/><Metric label="Events created" value={analytics?.total_events ?? 0}/><Metric label="Tickets sold" value={analytics?.total_tickets_sold ?? 0}/><Metric label="Bookings" value={analytics?.total_bookings ?? 0}/><Metric label="Platform revenue" value={`₹${(analytics?.total_revenue ?? 0).toLocaleString()}`}/></> : <><Metric label="Tickets sold" value={total.tickets_sold ?? 0}/><Metric label="Tickets remaining" value={total.remaining_tickets ?? 0}/><Metric label="Bookings" value={total.booking_count ?? 0}/><Metric label="Revenue" value={`₹${(total.revenue ?? 0).toLocaleString()}`}/></>}</div>
      {admin ? <div className="insight-grid"><Chart title="Daily ticket sales" rows={analytics?.daily_ticket_sales || []} label="date" value="tickets"/><Chart title="Monthly booking trends" rows={analytics?.monthly_booking_trends || []} label="month" value="bookings"/><Chart title="Popular events · tickets sold" rows={analytics?.popular_events || []} label="event" value="tickets"/><Chart title="Top revenue events" rows={analytics?.top_revenue_events || []} label="event" value="revenue" money/></div> : <Chart title="Event performance" rows={analytics?.events || []} label="event_title" value="tickets_sold"/>}
    </>}
    {tab === "events" && <section className="card"><div className="page-heading"><h2>{admin ? "All events" : "Your events"}</h2><button onClick={() => startEdit(null)}>Create event</button></div><Table rows={events} columns={[{key:"title",label:"Event"},{key:"event_date",label:"Date",render:r=>new Date(r.event_date).toLocaleString()},{key:"event_status",label:"Status",render:r=><span className={`status ${r.event_status?.toLowerCase()}`}>{r.event_status}</span>},{key:"available_tickets",label:"Remaining"},{key:"actions",label:"Actions",render:r=><span className="row-actions">{r.event_status!=="CANCELLED" && <><button className="small-button" onClick={()=>startEdit(r)}>Edit</button><button className="small-button danger" onClick={()=>cancel(r)}>Cancel</button></>}</span>}]}/></section>}
    {tab === "bookings" && <section className="card"><h2>{admin ? "All bookings" : "Bookings for your events"}</h2><Table rows={bookings} columns={[{key:"event_title",label:"Event"},{key:"username",label:"Booked by",render:r=>r.username || "You"},{key:"email",label:"Email"},{key:"ticket_quantity",label:"Tickets"},{key:"total_price",label:"Total",render:r=>`₹${Number(r.total_price).toLocaleString()}`},{key:"booking_status",label:"Status"},{key:"created_at",label:"Booked",render:r=>new Date(r.created_at).toLocaleDateString()},...(admin ? [{key:"actions",label:"Actions",render:r=>r.booking_status==="CONFIRMED" && new Date(r.event_date)>new Date() ? <button className="small-button danger" onClick={()=>cancelPlatformBooking(r)}>Cancel booking</button> : "—"}] : [])]}/></section>}
    {tab === "users" && <section className="card"><h2>Users and roles</h2><Table rows={users} columns={[{key:"username",label:"User"},{key:"email",label:"Email"},{key:"role",label:"Role",render:r=><select aria-label={`Role for ${r.username}`} value={r.role} disabled={r.id === user?.id} onChange={e=>changeRole(r,e.target.value)}>{["USER","ORGANIZER","ADMIN"].map(role=><option key={role}>{role}</option>)}</select>},{key:"created_at",label:"Joined",render:r=>new Date(r.created_at).toLocaleDateString()}]}/></section>}
  </main>;
}

function Chart({ title, rows, label, value, money=false }) {
  const max = Math.max(1, ...rows.map(r=>Number(r[value]) || 0));
  return <section className="card chart-card"><h3>{title}</h3>{rows.length ? rows.slice(0,10).map((r,i)=><div className="bar-row" key={`${r[label]}-${i}`}><span title={r[label]}>{r[label]}</span><div className="bar-track"><i style={{width:`${Math.max(3,(Number(r[value])/max)*100)}%`}}/></div><strong>{money ? `₹${Number(r[value]).toLocaleString()}` : r[value]}</strong></div>) : <p>No activity in this period.</p>}</section>;
}
