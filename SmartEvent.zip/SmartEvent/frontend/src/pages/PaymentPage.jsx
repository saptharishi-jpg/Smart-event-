import { useState } from "react";
import api, { authHeaders } from "../api";

export default function PaymentPage({ checkout, onPaid, onBack, showError }) {
  const [result, setResult] = useState("SUCCESS");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [discountInfo, setDiscountInfo] = useState(null);
  const [paymentInfo, setPaymentInfo] = useState(checkout?.payment || null);
  async function applyCoupon() {
    if (!couponCode.trim()) return;
    try {
      const response = await api.post(
        `/payments/${paymentInfo.id}/coupon`,
        { coupon_code: couponCode.trim() },
        { headers: authHeaders() },
      );
      setDiscountInfo(response.data);
      setPaymentInfo(response.data.payment);
      setStatus("");
    } catch (error) {
      setStatus(error.response?.data?.detail || "Coupon could not be applied.");
    }
  }
  async function pay() {
    if (!paymentInfo?.id)
      return showError("Payment information is missing. Please book again.");
    setLoading(true);
    setStatus("");
    try {
      const response = await api.post(
        `/payments/${paymentInfo.id}/simulate`,
        { result },
        { headers: authHeaders() },
      );
      onPaid(response.data);
    } catch (error) {
      setStatus(
        error.response?.data?.detail ||
          "Could not process the simulated payment.",
      );
    } finally {
      setLoading(false);
    }
  }
  const b = checkout?.booking || {};
  const subtotal = Number(
    discountInfo?.subtotal ?? checkout?.subtotal ?? b.total_price ?? 0,
  );
  const discount = Number(
    discountInfo?.discount_amount ??
      checkout?.discount_amount ??
      b.discount_amount ??
      0,
  );
  const amountToPay = Number(
    discountInfo?.final_amount ??
      checkout?.final_amount ??
      paymentInfo?.amount ??
      0,
  );
  return (
    <main className="container">
      <button className="secondary" onClick={onBack}>
        ← Back to event
      </button>
      <section className="card checkout-card">
        <p className="eyebrow"> </p>
        <h1>Complete your payment</h1>
        <p>
          This is a simulated payment for development. No real money will be
          charged.
        </p>
        <div className="summary-row">
          <span>Event</span>
          <strong>{b.event_title}</strong>
        </div>
        <div className="summary-row">
          <span>Tickets</span>
          <strong>{b.ticket_quantity}</strong>
        </div>
        <div className="summary-row">
          <span>Subtotal</span>
          <strong>₹{subtotal.toFixed(2)}</strong>
        </div>
        <div className="coupon-checkout">
          <label>
            Coupon code
            <input
              value={couponCode}
              placeholder="WELCOME10 or SAVE50"
              onChange={(e) => setCouponCode(e.target.value)}
            />
          </label>
          <button
            className="secondary"
            onClick={applyCoupon}
            disabled={!couponCode.trim()}
          >
            Apply coupon
          </button>
        </div>
        <div className="summary-row">
          <span>Discount</span>
          <strong>− ₹{discount.toFixed(2)}</strong>
        </div>
        <div className="summary-row total-row">
          <span>Amount to pay</span>
          <strong>₹{amountToPay.toFixed(2)}</strong>
        </div>
        <label className="payment-result-label">
          Choose a simulation result
          <select value={result} onChange={(e) => setResult(e.target.value)}>
            <option value="SUCCESS">Payment successful</option>
            <option value="FAILED">Payment failed</option>
          </select>
        </label>
        {status && <div className="error inline-alert">{status}</div>}
        <button className="pay-button" onClick={pay} disabled={loading}>
          {loading ? "Processing…" : `Pay ₹${amountToPay.toFixed(2)}`}
        </button>
        <small className="muted">
          Demo only · No card details are collected or stored.
        </small>
      </section>
    </main>
  );
}
