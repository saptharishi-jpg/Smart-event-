import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";

function BookingConfirmationPage({ booking, ticketCode, payment, message, bookingStatus, goTickets, goHome, retryPayment }) {
  const [qrUrl, setQrUrl] = useState("");
  const success = payment?.payment_status === "SUCCESS";

  useEffect(() => {
    let objectUrl = "";
    let active = true;
    setQrUrl("");
    if (!ticketCode) return undefined;
    api.get(`/tickets/${ticketCode}/qr`, { headers: authHeaders(), responseType: "blob" })
      .then((response) => {
        objectUrl = URL.createObjectURL(response.data);
        if (active) setQrUrl(objectUrl);
      })
      .catch(() => { if (active) setQrUrl(""); });
    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [ticketCode]);

  return (
    <main className="container">
      <div className="card confirmation">
        <p className="eyebrow">PAYMENT CONFIRMATION</p>
        <h1>{success ? "Booking Confirmed" : "Payment Failed"}</h1>
        <p>{message || (success ? "Your payment succeeded and your booking is confirmed." : "Your payment was not successful. No ticket has been issued.")}</p>
        {booking?.event_title && <p>Event: <strong>{booking.event_title}</strong></p>}
        {booking?.ticket_quantity && <p>Tickets: {booking.ticket_quantity}</p>}
        {booking && <><p>Subtotal: ₹{Number(booking.total_price || 0).toFixed(2)}</p>
          <p>Discount: − ₹{Number(booking.discount_amount || 0).toFixed(2)}</p>
          <p><strong>{success ? "Paid" : "Amount"}: ₹{Number(booking.final_amount ?? booking.total_price ?? payment?.amount ?? 0).toFixed(2)}</strong></p></>}
        <p className={success ? "success-label" : "error-label"}>Payment status: {payment?.payment_status || "UNKNOWN"}</p>
        {bookingStatus && <p>Booking status: <strong>{bookingStatus}</strong></p>}
        {payment?.transaction_id && <p>Transaction reference: <strong>{payment.transaction_id}</strong></p>}
        {ticketCode && <p>Ticket Code: <strong>{ticketCode}</strong></p>}
        {ticketCode && <div className="confirmation-qr">
          {qrUrl ? <>
            <img src={qrUrl} alt="Ticket QR code" className="qr-code" />
            <p>Show this QR code at the event entrance.</p>
            <a href={qrUrl} download={`${ticketCode}.png`} className="button-link">Download QR code</a>
          </> : <p className="muted">Loading your secure ticket QR code…</p>}
        </div>}
        <div className="confirmation-actions">
          {success && <button onClick={goTickets}>View My Tickets</button>}
          {!success && payment?.id && booking?.booking_status !== "CANCELLED" && <button onClick={retryPayment}>Try payment again</button>}
          <button className="secondary" onClick={goHome}>{success ? "Back to Events" : "Browse Events"}</button>
        </div>
      </div>
    </main>
  );
}

export default BookingConfirmationPage;
