import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";
import EventCard from "../components/EventCard";

function HomePage({ onViewEvent, showError }) {
  const [events, setEvents] = useState([]);
  const [filters, setFilters] = useState({ category: "All", search: "", location: "", start_date: "", end_date: "", sort_by: "date", min_price: "", max_price: "" });
  const [loading, setLoading] = useState(false);
  const [recommendations, setRecommendations] = useState({ recommended: [], trending: [] });
  async function loadEvents(e) {
    e?.preventDefault();
    setLoading(true);
    try {
      const params = Object.fromEntries(Object.entries(filters).filter(([, value]) => value !== ""));
      const response = await api.get("/events", { params });
      setEvents(response.data);
    } catch { showError("Could not load events."); }
    finally { setLoading(false); }
  }
  async function loadRecommendations() {
    try { setRecommendations((await api.get("/recommendations", { headers: authHeaders() })).data); } catch { /* personalization needs login */ }
  }
  useEffect(() => { loadEvents(); loadRecommendations(); }, []);
  function update(key, value) { setFilters(old => ({ ...old, [key]: value })); }
  return <main className="container">
    <section className="hero">
      <p className="eyebrow">MAKE YOUR NEXT MOMENT COUNT</p>
      <h1>Discover events worth showing up for.</h1>
      <p>Find experiences, book your tickets, and keep every plan in one place.</p>
      <form className="filters search-panel" onSubmit={loadEvents}>
        <input placeholder="Search event name or description" value={filters.search} onChange={e=>update("search",e.target.value)} />
        <input placeholder="City or location" value={filters.location} onChange={e=>update("location",e.target.value)} />
        <select value={filters.category} onChange={e=>update("category",e.target.value)}>
          {["All","Music","Tech","Sports","Business","Arts","Community","Other"].map(x=><option key={x}>{x}</option>)}
        </select>
        <label>From<input type="date" value={filters.start_date} onChange={e=>update("start_date",e.target.value)} /></label>
        <label>To<input type="date" value={filters.end_date} onChange={e=>update("end_date",e.target.value)} /></label>
        <label>Min price<input type="number" min="0" placeholder="₹ Min" value={filters.min_price} onChange={e=>update("min_price",e.target.value)} /></label>
        <label>Max price ₹{filters.max_price || "5000"}<input type="range" min="0" max="5000" step="100" value={filters.max_price || 5000} onChange={e=>update("max_price",e.target.value)} /></label>
        <select aria-label="Sort events" value={filters.sort_by} onChange={e=>update("sort_by",e.target.value)}>
          <option value="date">Sort: Date</option><option value="popularity">Sort: Popularity</option><option value="price">Sort: Price</option>
        </select>
        <button type="submit">Find events</button>
      </form>
    </section>
    {!!recommendations.recommended.length && <><div className="section-heading"><div><p className="eyebrow">PICKED FOR YOU</p><h2>Recommended for You</h2></div></div><div className="event-grid">{recommendations.recommended.slice(0,4).map(event=><EventCard key={`rec-${event.id}`} event={event} onView={onViewEvent}/>)}</div></>}
    {!!recommendations.trending.length && <><div className="section-heading"><div><p className="eyebrow">WHAT'S POPULAR</p><h2>Trending Events</h2></div></div><div className="event-grid">{recommendations.trending.slice(0,4).map(event=><EventCard key={`trend-${event.id}`} event={event} onView={onViewEvent}/>)}</div></>}
    <div className="section-heading"><div><p className="eyebrow">EXPLORE</p><h2>Upcoming experiences</h2></div><span>{events.length} events</span></div>
    {loading ? <div className="event-grid">{[1,2,3].map(n=><div className="card skeleton" key={n}><div/><div/><div/></div>)}</div> :
      <div className="event-grid">{events.map(event=><EventCard key={event.id} event={event} onView={onViewEvent}/>)}</div>}
    {!loading && !events.length && <div className="card empty-state"><h3>No events found</h3><p>Try changing your search or filters.</p></div>}
  </main>;
}
export default HomePage;
