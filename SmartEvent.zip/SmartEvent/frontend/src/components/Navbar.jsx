import { useState } from "react";
import api, { authHeaders } from "../api";
import NotificationDropdown from "./NotificationDropdown";

function Navbar({ user, page, setPage, onLogout, unreadCount, onNotificationsChanged }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  async function toggleNotifications() {
    const next = !open; setOpen(next);
    if (next) {
      try { setItems((await api.get("/notifications", { headers: authHeaders() })).data.slice(0, 5)); }
      catch { setItems([]); }
    }
  }
  async function markRead(id) {
    try {
      await api.patch(`/notifications/${id}/read`, {}, { headers: authHeaders() });
      setItems(old => old.map(item => item.id === id ? { ...item, is_read: true } : item));
      onNotificationsChanged?.();
    } catch { /* the notifications page shows API errors */ }
  }
  return (
    <nav className="navbar">
      <button className="logo" onClick={() => { setPage("home"); setOpen(false); }}>SmartEvent</button>
      <div className="nav-links">
        <button onClick={() => { setPage("home"); setOpen(false); }}>Events</button>
        <button onClick={() => { setPage("wishlist"); setOpen(false); }}>Wishlist</button>
        <button onClick={() => { setPage("profile"); setOpen(false); }}>Profile</button>
        {user?.role === "USER" && <>
          <button onClick={() => { setPage("bookings"); setOpen(false); }}>Bookings</button>
          <button onClick={() => { setPage("tickets"); setOpen(false); }}>Tickets</button>
        </>}
        {user?.role === "ORGANIZER" && <button onClick={() => { setPage("organizer"); setOpen(false); }}>Organizer dashboard</button>}
        {user?.role === "ADMIN" && <button onClick={() => { setPage("admin"); setOpen(false); }}>Admin dashboard</button>}
        <div className="notification-menu">
          <button onClick={toggleNotifications} aria-expanded={open}>🔔 Notifications ({unreadCount})</button>
          {open && <div className="notification-popover"><NotificationDropdown notifications={items} onRead={markRead}/><button className="secondary" onClick={()=>{setPage("notifications");setOpen(false);}}>View all notifications</button></div>}
        </div>
        <span>Hi, {user?.username} <small className="role-label">{user?.role}</small></span>
        <button className="danger" onClick={onLogout}>Logout</button>
      </div>
    </nav>
  );
}
export default Navbar;
