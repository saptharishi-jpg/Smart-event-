import { useEffect, useState } from "react";
import api, { authHeaders } from "../api";

function EventCard({ event, onView }) {
  const [saved, setSaved] = useState(false);
  const [available, setAvailable] = useState(event.available_tickets);
  useEffect(() => {
    setAvailable(event.available_tickets);
    let active = true;
    if (localStorage.getItem("token")) {
      api.get("/wishlist", { headers: authHeaders() })
        .then((r) => { if (active) setSaved(r.data.some((item) => Number(item.id) === Number(event.id))); })
        .catch(() => {});
    } else setSaved(false);
    const timer = setInterval(async () => {
      try { const r = await api.get(`/events/${event.id}/availability`); if (active) setAvailable(r.data.available_tickets); }
      catch { /* availability refresh is optional */ }
    }, 5000);
    return () => { active = false; clearInterval(timer); };
  }, [event.id, event.available_tickets]);
  async function toggleSave() {
    try {
      if (saved) await api.delete(`/wishlist/${event.id}`, { headers: authHeaders() });
      else await api.post(`/wishlist/${event.id}`, {}, { headers: authHeaders() });
      setSaved(!saved);
    } catch (e) { alert(e.response?.data?.detail || "Please log in to save events."); }
  }
  return <div className="card event-card">
    <div className="event-box">{event.category}</div>
    <div className="event-card-top"><h3>{event.title}</h3><button className="save-event" title="Save event" onClick={toggleSave}>{saved ? "♥ Saved" : "♡ Save"}</button></div>
    <p>{event.location}</p><p>{new Date(event.event_date).toLocaleString()}</p>
    <p><span className={`status ${event.event_status?.toLowerCase()}`}>{event.event_status}</span></p>
    <p><strong>₹{event.ticket_price}</strong></p><p>Tickets left: <strong>{available}</strong></p>
    <button onClick={() => onView(event.id)}>View Event</button>
  </div>;
}
export default EventCard;
