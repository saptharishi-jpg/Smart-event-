import { useState } from "react";
import api, { authHeaders } from "../api";

export default function ChatAssistant() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState([{ role: "assistant", text: "Hi! I can help you find events, check your bookings, and troubleshoot tickets." }]);
  async function send(value = text) {
    const q = value.trim(); if (!q || busy) return;
    setMessages(old => [...old, { role: "user", text: q }]); setText(""); setBusy(true);
    try { const r = await api.post("/assistant/chat", { message: q }, { headers: authHeaders() }); setMessages(old => [...old, { role: "assistant", text: r.data.reply }]); }
    catch (e) { setMessages(old => [...old, { role: "assistant", text: e.response?.data?.detail || "I could not answer right now. Please try again." }]); }
    finally { setBusy(false); }
  }
  return <div className="chat-assistant"><button className="chat-toggle" onClick={() => setOpen(!open)}>{open ? "Close assistant" : "💬 Ask SmartEvent"}</button>{open && <section className="chat-panel"><h3>SmartEvent Assistant</h3><div className="chat-messages">{messages.map((m,i)=><div key={i} className={`chat-message ${m.role}`}>{m.text}</div>)}{busy && <div className="chat-message assistant">Thinking…</div>}</div><div className="chat-suggestions"><button onClick={()=>send("Trending events")}>Trending events</button><button onClick={()=>send("Show my bookings")}>My bookings</button><button onClick={()=>send("Help with ticket issues")}>Ticket help</button></div><form onSubmit={e=>{e.preventDefault();send();}}><input value={text} onChange={e=>setText(e.target.value)} placeholder="Ask about events or tickets…" maxLength="1000"/><button disabled={busy}>Send</button></form></section>}</div>;
}
